DROB TWEAKS - FREE TRIAL
========================

HOW TO USE  (full picture guide: DROB Tutorial.pdf)
1. Right click the zip and choose "Extract All".
2. Double-click "DROB Trial.bat".
3. Pick an option in the menu.

If Windows asks "Do you want to run this file?" or shows "Windows protected
your PC", that is normal for any script you download. Click "More info" then
"Run anyway" (or "Open").

WHAT IT DOES
- Option 1: scans your PC. Read only. Changes nothing.
- Option 2: applies 8 safe tweaks plus a cleanup:
    1. Mouse acceleration off
    2. Sticky Keys and shortcut popups off
    3. Fastest keyboard repeat
    4. Background game recording off
    5. Fullscreen optimizations off
    6. Background apps off
    7. Transparency effects off
    8. High performance power plan (desktops only)
    +  Cleanup of junk temp files
- Option 3: undoes the tweaks and puts your original settings back.
- Option 4: shows what the full version adds.

Sign out and back in after applying so the mouse and keyboard changes
fully take effect. Results vary per PC.

IS IT SAFE?
- No admin needed. Nothing is installed. Nothing is downloaded.
- It only changes settings for your own Windows user account.
- "DROB Trial.bat" is plain text. Open it in Notepad and read every line.
- Your original settings are saved in %APPDATA%\DROB_Trial

FULL VERSION (100+ tweaks, 6 apps, bundles)
https://drobtweaks.com
Support: https://discord.gg/cnYkBG5Duy
