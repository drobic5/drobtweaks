@echo off
setlocal EnableExtensions EnableDelayedExpansion
title DROB TWEAKS - Free Trial
mode con: cols=92 lines=46 >nul 2>&1

rem ============================================================
rem  DROB TWEAKS - FREE TRIAL
rem  Plain text script. Open it in Notepad to see everything it does.
rem  No admin needed. Nothing is installed. Nothing is downloaded.
rem  Only changes settings for YOUR user account, and can be undone.
rem ============================================================

for /F "delims=#" %%E in ('"prompt #$E# & for %%E in (1) do rem"') do set "ESC=%%E"
set "R=%ESC%[91m"
set "W=%ESC%[97m"
set "G=%ESC%[92m"
set "D=%ESC%[90m"
set "N=%ESC%[0m"
set "BK=%APPDATA%\DROB_Trial"
set "SITE=https://drobtweaks.com"
goto menu

:banner
cls
echo.
echo %R%  ==========================================================================================%N%
echo %W%     D R O B   T W E A K S%N%       %D%FREE TRIAL%N%
echo %R%  ==========================================================================================%N%
echo.
exit /b

:ok
echo   %G%[ OK ]%N%  %~1
exit /b

:bad
set /a ISSUES+=1
echo   %R%[ NO ]%N%  %~1
exit /b

:getval
set "VAL="
for /f "tokens=3" %%a in ('reg query "%~1" /v "%~2" 2^>nul ^| find /i "%~2"') do set "VAL=%%a"
exit /b

:menu
call :banner
echo   %W%What do you want to do?%N%
echo.
echo   %R%[1]%N% Scan my PC              %D%free, read only, changes nothing%N%
echo   %R%[2]%N% Apply the free tweaks   %D%8 safe tweaks + cleanup, fully undoable%N%
echo   %R%[3]%N% Undo the free tweaks    %D%puts everything back%N%
echo   %R%[4]%N% Full version            %D%see everything DROB can do%N%
echo   %R%[X]%N% Exit
echo.
choice /c 1234X /n /m "  Choose an option: "
if errorlevel 5 goto end
if errorlevel 4 goto full
if errorlevel 3 goto undo
if errorlevel 2 goto apply
goto scan

:scan
call :banner
echo   %W%Scanning your PC. This only reads settings, nothing is changed.%N%
echo.
set /a ISSUES=0
set "CPU=unknown"
set "GPU="
set "OSV=Windows"

for /f "tokens=2*" %%a in ('reg query "HKLM\HARDWARE\DESCRIPTION\System\CentralProcessor\0" /v ProcessorNameString 2^>nul ^| find "ProcessorNameString"') do set "CPU=%%b"
for %%i in (0000 0001 0002 0003) do for /f "tokens=2*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11cd-bfc1-08002be10318}\%%i" /v DriverDesc 2^>nul ^| find "DriverDesc"') do call :addgpu "%%b"
if not defined GPU set "GPU=unknown"
for /f "tokens=*" %%a in ('ver') do set "OSV=%%a"

echo   %D%System%N%
echo   CPU      : !CPU!
echo   GPU      : !GPU!
echo   Threads  : %NUMBER_OF_PROCESSORS%
echo   Windows  : !OSV!
echo.
echo   %D%Findings%N%

set "PLAN="
for /f "tokens=2 delims=:" %%a in ('powercfg /getactivescheme 2^>nul') do for /f "tokens=1" %%b in ("%%a") do set "PLAN=%%b"
set "PERF=0"
if /i "!PLAN!"=="8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c" set "PERF=1"
if /i "!PLAN!"=="e9a42b02-d5df-448d-aa00-03f14749eb61" set "PERF=1"
if "!PERF!"=="1" (call :ok "Power plan is set for performance") else call :bad "Power plan is not set for performance, fine on a laptop"

call :getval "HKCU\Control Panel\Mouse" MouseSpeed
if "!VAL!"=="0" (call :ok "Mouse acceleration is off") else call :bad "Mouse acceleration is ON, it hurts aim consistency"

call :getval "HKCU\Control Panel\Accessibility\StickyKeys" Flags
if "!VAL!"=="506" (call :ok "Sticky Keys popup is off") else call :bad "Sticky Keys popup can interrupt your game when you spam Shift"

call :getval "HKCU\Control Panel\Keyboard" KeyboardDelay
if "!VAL!"=="0" (call :ok "Keyboard repeat delay is at the fastest") else call :bad "Keyboard repeat delay is not at the fastest setting"

call :getval "HKCU\System\GameConfigStore" GameDVR_Enabled
if "!VAL!"=="0x0" (call :ok "Background game recording is off") else call :bad "Background game recording is not disabled"

call :getval "HKCU\System\GameConfigStore" GameDVR_FSEBehaviorMode
if "!VAL!"=="0x2" (call :ok "Fullscreen optimizations are off") else call :bad "Fullscreen optimizations are on, can add input delay in some games"

call :getval "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" GlobalUserDisabled
if "!VAL!"=="0x1" (call :ok "Background apps are off") else call :bad "Background apps are allowed to run"

call :getval "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" EnableTransparency
if "!VAL!"=="0x0" (call :ok "Transparency effects are off") else call :bad "Transparency effects use GPU for no gain"

set /a SU=0
for /f %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" 2^>nul ^| find /c "REG_"') do set /a SU+=%%a
for /f %%a in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" 2^>nul ^| find /c "REG_"') do set /a SU+=%%a
if !SU! GTR 6 (call :bad "!SU! programs start with Windows, this slows boot") else call :ok "!SU! programs start with Windows"

set /a PR=0
for /f %%a in ('tasklist /nh 2^>nul ^| find /c /v ""') do set /a PR=%%a
if !PR! GTR 130 (call :bad "!PR! background processes are running") else call :ok "!PR! background processes are running"

set /a TF=0
for /f %%a in ('dir /a-d /b /s "%TEMP%" 2^>nul ^| find /c /v ""') do set /a TF=%%a
if !TF! GTR 200 (call :bad "!TF! junk files in your Temp folder") else call :ok "Temp folder is fairly clean"

echo.
if !ISSUES! GTR 0 goto scan_bad
echo   %G%Your PC looks clean.%N% The full version still has 100+ more tweaks.
goto scan_end
:scan_bad
echo   %R%!ISSUES! things can be improved on this PC.%N%
echo   The free tweaks fix most of the settings. The full version goes much deeper.
:scan_end
echo.
echo   %W%Only in the full version:%N%
echo   %D%[LOCKED]%N% Debloat and telemetry off ......... DROB DEBLOAT     $5
echo   %D%[LOCKED]%N% 30+ registry tweaks ............... REGISTRY TWEAKS  $10
echo   %D%[LOCKED]%N% Drivers, ping optimizer, startup .. DROB TOOL        $15
echo   %D%[LOCKED]%N% Per-game tuning and live stats .... DROB ZD          $20
echo   %D%[LOCKED]%N% AI tweaker that applies for you ... DROB AI          $25
echo.
choice /c ABM /n /m "  [A] Apply free tweaks   [B] Get the full version   [M] Menu: "
if errorlevel 3 goto menu
if errorlevel 2 goto site
goto apply

:addgpu
if defined GPU (set "GPU=!GPU! / %~1") else set "GPU=%~1"
exit /b

:apply
call :banner
echo   %W%These free tweaks are safe. Your original settings are saved so you can undo:%N%
echo.
echo     1. Mouse acceleration off
echo     2. Sticky Keys and shortcut popups off
echo     3. Fastest keyboard repeat
echo     4. Background game recording off
echo     5. Fullscreen optimizations off
echo     6. Background apps off
echo     7. Transparency effects off
echo     8. High performance power plan  %D%desktop only%N%
echo     +  Cleanup of junk temp files
echo.
choice /c YN /n /m "  Continue? [Y/N]: "
if errorlevel 2 goto menu
echo.
choice /c DL /n /m "  Is this PC a [D]esktop or a [L]aptop? "
set "LAPTOP=0"
if errorlevel 2 set "LAPTOP=1"
echo.
if not exist "%BK%" md "%BK%"
if not exist "%BK%\plan.txt" call :saveplan

call :setreg "HKCU\Control Panel\Mouse" MouseSpeed REG_SZ 0
call :setreg "HKCU\Control Panel\Mouse" MouseThreshold1 REG_SZ 0
call :setreg "HKCU\Control Panel\Mouse" MouseThreshold2 REG_SZ 0
call :ok "1. Mouse acceleration off"

call :setreg "HKCU\Control Panel\Accessibility\StickyKeys" Flags REG_SZ 506
call :setreg "HKCU\Control Panel\Accessibility\ToggleKeys" Flags REG_SZ 58
call :setreg "HKCU\Control Panel\Accessibility\Keyboard Response" Flags REG_SZ 122
call :ok "2. Sticky Keys and shortcut popups off"

call :setreg "HKCU\Control Panel\Keyboard" KeyboardDelay REG_SZ 0
call :setreg "HKCU\Control Panel\Keyboard" KeyboardSpeed REG_SZ 31
call :ok "3. Fastest keyboard repeat"

call :setreg "HKCU\System\GameConfigStore" GameDVR_Enabled REG_DWORD 0
call :setreg "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" AppCaptureEnabled REG_DWORD 0
call :ok "4. Background game recording off"

call :setreg "HKCU\System\GameConfigStore" GameDVR_FSEBehaviorMode REG_DWORD 2
call :setreg "HKCU\System\GameConfigStore" GameDVR_FSEBehavior REG_DWORD 2
call :setreg "HKCU\System\GameConfigStore" GameDVR_HonorUserFSEBehaviorMode REG_DWORD 1
call :setreg "HKCU\System\GameConfigStore" GameDVR_DXGIHonorFSEWindowsCompatible REG_DWORD 1
call :setreg "HKCU\System\GameConfigStore" GameDVR_EFSEFeatureFlags REG_DWORD 0
call :ok "5. Fullscreen optimizations off"

call :setreg "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" GlobalUserDisabled REG_DWORD 1
call :ok "6. Background apps off"

call :setreg "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" EnableTransparency REG_DWORD 0
call :ok "7. Transparency effects off"

if "!LAPTOP!"=="1" goto plan_laptop
powercfg /setactive SCHEME_MIN >nul 2>&1
if errorlevel 1 goto plan_skip
call :ok "8. High performance power plan is active"
goto plan_done
:plan_laptop
echo   %D%[ -- ]%N%  8. Power plan skipped on laptops, it would drain your battery
goto plan_done
:plan_skip
echo   %D%[ -- ]%N%  8. Power plan not available on this PC, skipped
:plan_done

set /a TB=0
for /f %%a in ('dir /a-d /b /s "%TEMP%" 2^>nul ^| find /c /v ""') do set /a TB=%%a
call :cleantemp
set /a TA=0
for /f %%a in ('dir /a-d /b /s "%TEMP%" 2^>nul ^| find /c /v ""') do set /a TA=%%a
set /a TR=TB-TA
if !TR! LSS 0 set /a TR=0
call :ok "+  Removed !TR! junk files from Temp"

echo.
echo   %G%Done.%N% Sign out and back in so mouse and keyboard changes fully apply.
echo   Undo any time from the main menu, option 3.
echo   %D%The temp cleanup only removes junk files and can not be undone.%N%
echo.
echo   %W%Want the other 100+ tweaks?%N% The full version goes much deeper, safely.
echo.
choice /c BM /n /m "  [B] Get the full version   [M] Menu: "
if errorlevel 2 goto menu
goto site

:setreg
rem usage: call :setreg "key" name type data   (saves the original value once, then sets the new one)
set "HAVE=0"
if exist "%BK%\values.txt" findstr /b /l /c:"%~1|%~2|" "%BK%\values.txt" >nul 2>&1 && set "HAVE=1"
if "!HAVE!"=="1" goto setreg_write
set "OT=MISSING"
set "OD=-"
for /f "tokens=2*" %%a in ('reg query "%~1" /v "%~2" 2^>nul ^| find /i "%~2"') do set "OT=%%a" & set "OD=%%b"
>>"%BK%\values.txt" echo %~1^|%~2^|!OT!^|!OD!
:setreg_write
reg add "%~1" /v "%~2" /t %~3 /d %~4 /f >nul 2>&1
exit /b

:saveplan
for /f "tokens=2 delims=:" %%a in ('powercfg /getactivescheme 2^>nul') do for /f "tokens=1" %%b in ("%%a") do >"%BK%\plan.txt" echo %%b
exit /b

:cleantemp
if not defined TEMP exit /b
if not exist "%TEMP%\" exit /b
echo %TEMP%| find /i "temp" >nul
if errorlevel 1 exit /b
del /f /s /q "%TEMP%\*" >nul 2>&1
for /d %%d in ("%TEMP%\*") do rd /s /q "%%d" >nul 2>&1
exit /b

:undo
call :banner
if not exist "%BK%\values.txt" goto undo_none
echo   %W%Putting your original settings back...%N%
echo.
for /f "usebackq tokens=1-4 delims=|" %%a in ("%BK%\values.txt") do call :restore "%%a" "%%b" "%%c" "%%d"
if exist "%BK%\plan.txt" call :restoreplan
call :ok "All free tweaks undone, original settings restored"
del /q "%BK%\values.txt" >nul 2>&1
del /q "%BK%\plan.txt" >nul 2>&1
echo.
echo   %D%Sign out and back in so everything fully applies.%N%
echo.
pause
goto menu
:undo_none
echo   %D%Nothing to undo yet. You have not applied the free tweaks.%N%
echo.
pause
goto menu

:restore
if "%~3"=="MISSING" goto restore_del
reg add "%~1" /v "%~2" /t %~3 /d "%~4" /f >nul 2>&1
exit /b
:restore_del
reg delete "%~1" /v "%~2" /f >nul 2>&1
exit /b

:restoreplan
for /f "usebackq tokens=1" %%a in ("%BK%\plan.txt") do powercfg /setactive %%a >nul 2>&1
exit /b

:full
call :banner
echo   %W%FREE TRIAL vs FULL VERSION%N%
echo.
echo   %G%Free trial%N%
echo     PC scan and 8 safe tweaks
echo.
echo   %R%Full version%N%
echo     DROB DEBLOAT       $5   strip bloat and telemetry
echo     REGISTRY TWEAKS   $10   30+ .reg files, restore point first
echo     DROB TOOL         $15   drivers, ping optimizer, startup manager
echo     DROB KBM          $15   mouse and keyboard deep tuning
echo     DROB ZD           $20   live stats and per-game tuning
echo     DROB AI           $25   chat-based AI tweaker
echo     Bundles from $30, and every product for $80
echo.
choice /c OM /n /m "  [O] Open drobtweaks.com   [M] Menu: "
if errorlevel 2 goto menu

:site
start "" "%SITE%"
goto menu

:end
endlocal
exit /b
